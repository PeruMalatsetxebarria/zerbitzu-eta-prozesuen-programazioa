public class adibidea34 {
    public static void main (String[] args) {
        Runtime r = Runtime.getRuntime();
        String comando= "NOTEPAD"; //calc, CMD /C DIR
        Process p;
        try {
            p = r.exec(comando);
        }
        catch (Exception e) {
            System.out.println("Error e n : "+comando );
            e .printStackTrace() ;
        }
    }
}